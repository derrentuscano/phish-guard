// ============================================================
// config.js — PhishGuard Extension Configuration
// ⚠️  This file is gitignored — never commit it.
//     Copy config.example.js → config.js and fill in your values.
// ============================================================

const EXT_CONFIG = {
  GSB_API_KEY:      'AIzaSyDuGWhyde55yiu7EJM7eUOR22lVUAPNyYI',
  FIREBASE_PROJECT: 'phish-guard-316c9',
};
